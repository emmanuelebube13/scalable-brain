# Brief: Build a Swing-Trading Strategy Qualification System from First Principles

## The assignment

Build a research system that determines, honestly, whether any of six rule-based
swing-trading strategies has a durable edge in FX — across different market conditions and
across roughly two decades of history — and whether that edge is stable enough to be
automated forward into markets that have not happened yet.

You will design and write the entire system: data collection, storage, feature engineering,
market-condition modelling, backtesting, evaluation criteria, validation methodology, and
the design for a live inference path. You write all the code and all the SQL. A human
operator runs it. A reviewer reads your code statically before it runs.

**You will not be told which strategies passed.** More on this below — it is a structural
constraint on the whole engagement, not a formality.

Four documents accompany this brief:

- **`01-strategy-specs.md`** — the six strategies. The object under test.
- **`02-oanda-data-contract.md`** — the broker data API, its traps, and the instrument universe.
- **`03-runtime-environment.md`** — the machine, the database, and the execution model.
- **`04-failure-history.md`** — what has gone wrong in two years of previous attempts.

Read all four before designing anything. `04` is the most important one.

---

## 1. The core thesis under test

A previous system was built on the following thesis. State it back in your own words before
you critique it, so we can confirm you have understood it:

> A library of rule-based strategies can be qualified for live capital by (a) labelling
> historical market conditions into a small number of regimes, (b) measuring each strategy's
> out-of-sample performance conditioned on regime, (c) admitting only the combinations that
> clear pre-set statistical bars, and (d) routing capital at runtime to the admitted
> combinations according to the currently detected regime. Governing principle: preservation
> of capital over profit — no strategy touches live capital until it has demonstrated an
> edge that survives honest out-of-sample measurement.

That system ran this thesis to completion once. Its single qualified output was an artifact
of a measurement error, and with the error removed nothing qualified at all.

**Your first deliverable is a critique of this thesis.** Where is it sound? Where is it
unfalsifiable, circular, or asking more of the data than the data can support? Is
regime-conditioning a real idea or a way of slicing a sample until something looks
significant? Does "preservation over profit" have operational content or is it a slogan?

Two rules on the critique:

- **Be direct.** We are not looking for validation. If you think the whole approach is
  unsound, say so plainly and argue it.
- **Flag, do not unilaterally replace.** The core vision — a governed, auditable process
  where nothing reaches live capital without demonstrated out-of-sample edge — is not yours
  to discard. If part of the method seems wrong, write down the objection, propose an
  alternative, explain the trade-off, and proceed with your alternative *clearly marked as a
  deviation*. What we will not accept is a silent substitution discovered later in the code.

---

## 2. What is frozen, and what is yours

**Frozen — do not change:**

- The six strategy concepts, exactly as specified in `01-strategy-specs.md`. Their entry and
  exit *logic* is the object under test. Changing it means we are no longer testing anything.
- The causality requirement in that same document. Non-negotiable.
- The instrument universe: the seven major pairs listed in `02`. You choose which to use.
- The blind protocol in section 3 below.
- Everything must be reproducible from your code plus the operator's data. No manual steps
  that only you know about.

**Yours — decide and justify every one of these:**

- How far back to collect data, at what granularities, for which instruments.
- The entire database schema, and whether to use a time-series extension at all.
- Every feature. We are giving you no feature list, no indicator set, and no starting point.
  Derive what the strategies and your evaluation actually need.
- How to model market conditions, if you conclude that is worth doing at all.
- **Every evaluation metric and every threshold.** We are deliberately not telling you what
  the previous system used, because we do not want you reproducing its numbers. Decide what
  "this strategy has an edge" should mean, define it precisely, and defend it.
- The entire validation methodology — train/test structure, how you handle the fact that you
  are evaluating a large combinatorial space, and how you establish that a result is not
  noise.
- The cost model.
- Position sizing and portfolio construction.
- The pipeline architecture itself.

You are being given unusual freedom here on purpose. The previous system's choices are not
available to you, and where a document mentions one it is labelled as historical context
with no authority. Do not try to reverse-engineer what we did. Build what is right.

**This is a swing-trading system.** Positions are intended to be held for days, not minutes
and not months. That is the one design constraint on your choices — it should drive your
timeframe selection, your holding-period rules, your cost model (multi-day holds accrue
overnight financing), and your view of what an acceptable trade frequency looks like. The
previous system only ever tested hourly and four-hourly bars with a daily filter; whether
that was appropriate for a swing system was never established. Determine it yourself.

---

## 3. The blind protocol

**You will never see strategy performance results.** Not returns, not risk-adjusted ratios,
not win rates, not equity curves, not rankings, not which strategy or configuration passed.

This exists because of failure #1 in `04-failure-history.md`. A team that sees results while
designing the evaluation will tune the evaluation, usually without intending to and usually
without noticing. Removing the feedback channel is the only reliable way to prevent it.
Nothing else on this project matters as much.

### The mechanical contract

Your pipeline must separate its outputs into two destinations, by construction:

- **`diagnostics/`** — structural information only. Row counts, date coverage, null and NaN
  rates, distinct-value counts, gap detection, schema validation results, runtime, memory,
  error traces, stack traces, signal *counts* per strategy, feature distribution summaries,
  convergence and fit diagnostics for any model you train. **This is returned to you.** It
  is how you debug.
- **`results/`** — anything that speaks to whether a strategy makes money. Per-trade
  outcomes, P&L, any performance metric, rankings, qualification verdicts, regime-conditioned
  performance, portfolio equity. **This is never returned to you.** The operator and reviewer
  read it.

Design this split into your architecture. Do not implement it as a filtering step at the
end — a performance number that reaches a log file, an exception message, a progress bar, or
a diagnostic summary has escaped. Make the separation a property of the code's structure,
name the mechanism that enforces it, and write tests that fail if a performance quantity can
reach the diagnostic path.

### Signal counts are the boundary

You may see how many signals a strategy generated. That is a structural fact and you need it
— zero signals means a bug, and a strategy firing 50,000 times on a daily timeframe means a
bug too. You may not see what those signals earned. Where the boundary is ambiguous, put the
quantity in `results/`.

### If results reach you anyway

Declare it in writing immediately, state exactly what you saw, and mark every design
decision made after that point as contaminated. Do not quietly carry on. An admitted leak we
can reason about; an unadmitted one invalidates the entire exercise.

### What this means for how you work

You cannot iterate toward a good-looking result, so do not try. Your evaluation criteria must
be **pre-registered** — written down, justified, and frozen *before* the pipeline that
measures them ever runs. If you later want to change a threshold or add a metric, that is
allowed, but it must be a documented, dated, reasoned amendment, not a silent edit. The
sequence of amendments is itself something the reviewer will look at.

---

## 4. First principles, and explainability

Do not import a standard quant-research pipeline template. Derive your architecture from the
question being asked and defend each stage. For every component, be able to answer: what
question does this stage answer, what would it look like if this stage were wrong, and what
would we lose by deleting it?

The system must be **modular**: the cost model, the market-condition model, the metric set,
the validation scheme, and the portfolio layer must each be swappable without touching the
others. Every one of them is a hypothesis we may want to vary. If changing the cost model
requires editing the backtester, the design has failed.

Every stage must be **explainable in prose** to someone who has not read the code. A pipeline
nobody can explain is one nobody can audit, and — see failure #10 — that is how the previous
system got into trouble.

---

## 5. Statistical requirements you must address explicitly

Not prescriptions. Problems you must show you have solved, in writing, in your methodology
document.

- **Multiple comparisons.** Six strategies × seven instruments × several timeframes ×
  parameter choices × market-condition buckets is an enormous space. Something in it will
  look excellent by chance. Quantify how many effective comparisons you make and account for
  it. A result that does not survive this correction has not been demonstrated.
- **Sample size per cell.** Swing strategies on daily-ish timeframes produce few trades.
  Slice by instrument and market condition and you can reach cells with a handful of trades
  that will nonetheless report spectacular ratios. Define minimum evidence for a cell to be
  evaluated at all, and state what you do with cells below it.
- **Non-independence across instruments.** Seven pairs sharing USD on one side are not seven
  independent experiments. This affects both portfolio risk and your significance testing.
- **Regime-boundary honesty.** If you model market conditions, the label at any bar must be
  computable from information available at that bar. A label derived with knowledge of how
  the period turned out will inflate every downstream result and is very hard to detect from
  the results alone.
- **Parameter selection is part of the strategy.** If you choose parameters by looking at
  performance, that choice must sit inside your out-of-sample structure, not outside it.
- **Regime shift over two decades.** 2004 FX is not 2026 FX. Say explicitly whether you
  treat the full history as one population, and what you do about it if not.
- **Costs.** See `02` for the spread and financing situation. Report the cost level at which
  each result would disappear.

---

## 6. Phases and gates

Deliver in phases. Each phase ends with the operator running your code and reporting back
structural diagnostics only. Do not begin a later phase's implementation before the earlier
phase has actually executed successfully — code written against data that has never been
looked at is how round trips get wasted.

**Phase 0 — Design.** No code. The thesis critique. The architecture document with
justification for every stage. The pre-registered evaluation criteria and validation design.
The blind-protocol enforcement mechanism. Your data collection plan with reasoning for depth,
granularity, and instrument selection. The schema design with DDL. Open questions for the
operator. *Gate: reviewer approves the design and the pre-registration before any measurement
code is written.*

**Phase 1 — Data.** Migrations, ingestion, data-quality validation, gap detection,
reconciliation. Must run in `--dry-run` and `--smoke` before the full backfill.
*Gate: the operator reports coverage, row counts and quality diagnostics; you confirm they
match what your design expects, in writing, before proceeding.*

**Phase 2 — Features and strategy implementation.** The feature layer and the six strategies
implemented from spec. Causality tests. Signal-count diagnostics.
*Gate: signal counts are structurally plausible on every strategy × instrument × timeframe.
A strategy firing zero times, or absurdly often, is a bug to fix now — not a result.*

**Phase 3 — Market-condition modelling.** Your own approach, designed independently. Fit
diagnostics, stability diagnostics, and evidence that the labels are causal and carry
information.
*Gate: after you deliver this, we will send you our previous regime implementation and the
finding that it failed to discriminate. You will then reconcile the two approaches and
explain the divergence. We are deliberately withholding it until now so that your design is
genuinely independent.*

**Phase 4 — Evaluation.** Backtesting, cost modelling, the validation scheme, metric
computation, qualification against your pre-registered criteria, portfolio construction.
Everything performance-related writes to `results/`.
*Gate: the operator and reviewer read the results. You receive structural diagnostics only.*

**Phase 5 — Live inference design.** **Design and specification only — no runnable trading
code in this engagement.** How a qualified configuration would be deployed, how live
inference would work, how it stays consistent with what was backtested, and the full
safeguard contract. Write it as if a strategy had qualified, while recognising that none may
have.

The safeguards we care about are not only risk limits. Read failure #5 and #6 in `04`: the
previous system's most dangerous failures were *silence* — pipelines that died and kept
reporting success, and stale artifacts served as current. Your safeguard design must address
staleness detection, heartbeat and liveness, provenance and versioning of every deployed
artifact, verification that the live signal path reproduces the backtested one, kill
switches, and what the system does by default when it is uncertain. Specify what happens on
every failure mode, not just the ones you expect.

---

## 7. What would make us reject the work

- Any look-ahead. This is fatal and non-negotiable. Assume the reviewer will hunt for it
  specifically, in your indicators, your labels, your normalisation, and your parameter
  selection.
- A performance number reaching the diagnostic path.
- Evaluation criteria that changed after results existed, without a documented amendment.
- Code that has obviously never been reasoned about at execution level — no precondition
  checks, no dry-run path, no error handling, unresumable long jobs.
- Any reference to, or connection to, the existing production database.
- Credentials in code.
- A large single delivery instead of gated phases.
- Silently changing the six strategies' logic.
- A confident conclusion unsupported by the statistical requirements in section 5.
- Presenting a result as tradeable when the cost model that produced it is optimistic.

---

## 8. On the expected outcome

We think it is likely that none of these six strategies has a durable, tradeable edge.

That is not pessimism and it is not a hint — it is the prior a previous two-year effort
produced, and you should hold it lightly but hold it. Its practical implication: **a
rigorous, well-evidenced negative result is a complete and successful deliverable.** If your
honest conclusion is that nothing qualifies, say so clearly, show the work, and tell us what
would need to be true for the answer to change.

We are more interested in whether the *method* is sound than in whether these six particular
strategies work. A system that reliably tells us "no" is far more valuable than one that
produces an encouraging number we cannot trust — we have already had one of those, and it
cost us two years.

---

## 9. Working rules

- **The operator runs everything.** Every command you need run must be given explicitly and
  completely: the exact command line, the working directory, what it will do, roughly how
  long it should take, what success looks like, and how to tell if it went wrong.
- **Ask questions rather than assume.** If the brief is ambiguous, ask. A wrong assumption
  costs a full round trip. But do not block on questions you can answer yourself by making a
  documented, reversible choice — state the assumption and proceed.
- **Never ask for performance information**, in any form, however indirect.
- **Parallel work discipline.** If you are distributing this across many agents: define the
  interfaces and data contracts *first* and freeze them before implementation starts; give
  every module exactly one owner; keep a manifest of every file and its purpose; and have a
  single agent responsible for coherence across the whole tree. A delivery where four modules
  each invented their own timestamp convention is worse than a slower, smaller one. Volume of
  code is not the deliverable — a system that runs correctly the first time it is executed
  by a human who cannot debug it is the deliverable.
- **Say what you are unsure about.** Flag anything you could not verify, anything you guessed
  at, and anything about the API or environment that you are inferring rather than knowing.
  The reviewer can check specific claims; they cannot check unstated confidence.

Begin with Phase 0. Deliver the thesis critique first, before the architecture — we want to
know what you think of the idea before you have invested in a design for it.
