# Runtime Environment and Execution Model

## The execution model — read this first, it shapes everything you write

**You cannot run anything.** No network, no database, no interpreter. Every script you write
will be executed for the first time by a human operator on their machine, after a reviewer
has read it statically.

Concretely, this means:

- **A crash costs a full round trip.** Assume every unguarded assumption will cost hours.
- **The reviewer can catch** wrong API usage, SQL errors, look-ahead in your logic, schema
  mismatches, unit errors, unsafe operations, and logic that contradicts your own design.
- **The reviewer cannot catch** data-shape surprises, real value distributions, performance
  characteristics, or anything that only appears when real data flows through.

So the burden is on your code to be self-verifying. Requirements, not suggestions:

1. **Every script accepts `--dry-run`** (validate config, connectivity, schema, and
   preconditions; write nothing) **and `--smoke`** (one instrument, a short window, full
   path end to end — should complete in well under a minute).
2. **Every script asserts its preconditions loudly at startup** and exits non-zero with a
   specific message. Missing env var, absent table, wrong schema version, unexpected column
   type, empty upstream — all named explicitly. Never proceed on a default.
3. **Every script is idempotent and resumable.** Re-running must converge to the same state,
   never duplicate rows. Use upserts keyed on a natural primary key.
4. **Every script prints a structured summary on completion**: rows read, rows written, rows
   skipped and why, time range covered, wall time, and a content hash where meaningful.
5. **Ship an expected-output block with each script** — what a correct run looks like, and
   the specific numbers or invariants the operator should check. This is how we verify
   without you being able to.
6. **No destructive default.** Anything that drops, truncates, or overwrites requires an
   explicit flag and prints what it is about to destroy first.

## Machine

- Ubuntu Linux, x86-64. Single machine, no cluster.
- **Python 3.12.3.** The operator will create a dedicated virtual environment for this
  project. Ship a `requirements.txt` with pinned versions. Prefer widely-used, stable
  libraries; if you want something unusual, justify it — every dependency is a thing the
  operator has to install and the reviewer has to trust.
- Ordinary developer hardware. Assume you have RAM in the tens of gigabytes, not hundreds,
  and no GPU. Given the data volume involved (see the data contract) this is not a real
  constraint, but do not design anything that assumes it can hold every instrument ×
  timeframe × parameter combination in memory at once.

## Database

- **PostgreSQL 16.14**, running locally on `localhost:5432`, confirmed accepting
  connections.
- **TimescaleDB is installed** on this cluster (version reported as 2.26.3 in project
  documentation; the operator can confirm the exact version). Hypertables, compression, and
  continuous aggregates are available to you.
- Credentials come from environment variables. Never hardcode them, never log them.

**You must design your own schema.** Write the DDL yourself. You decide tables, keys,
indexes, partitioning, whether to use TimescaleDB hypertables at all, whether to keep
features in the database or in files on disk, and how to version everything. Justify the
choices — including a decision *not* to use TimescaleDB, which is a perfectly reasonable
outcome if plain PostgreSQL tables serve better.

**Hard constraint: create and use a new, separate database.** There is an existing
production database on this same cluster called `ForexBrainDB`. Your scripts must never
connect to it, read from it, or write to it. Nothing you produce may reference it. The
database name must come from an environment variable so the operator controls it, and your
scripts should refuse to run if the target database name matches the production one.

## SQL delivery

The operator runs SQL by hand. So:

- Deliver DDL as **numbered, ordered migration files** (`001_...sql`, `002_...sql`), each
  independently runnable and each safe to re-run (`IF NOT EXISTS`, or guarded).
- Give the exact `psql` command line for each, and say what a successful run prints.
- Include a verification query after each migration that the operator can run to confirm the
  result, along with the expected output.
- Parameterised SQL only in application code. No string interpolation into queries anywhere.
- No `DROP` or `TRUNCATE` outside an explicitly-flagged teardown script.

## Secrets

Credentials will never appear in anything you receive, and must never appear in anything you
produce. Ship a `.env.example` with keys and empty values, document each one, and read them
at runtime. If a script needs a credential it does not have, it fails immediately with a
message naming the missing variable.

## Delivery format

The operator will receive your work as a file tree. Make it a repository:

- A top-level `README.md` that explains what the system is, how the pieces fit, and the
  exact order to run things.
- A `RUNBOOK.md` with the literal commands, in sequence, with expected output for each.
- Source organised by pipeline stage, one concern per module, pure computation separated
  from I/O so that logic is testable without a database.
- Tests that run without network or database access, covering at minimum: your causality
  guarantees, your cost model, your metric calculations, and your validation-split logic.
  These the operator *can* run, and they are the main evidence we have that your code does
  what you say.
- A `MANIFEST.md` listing every file with a one-line purpose. With a large team working in
  parallel, this is what keeps the delivery reviewable.
- Configuration in files, not scattered constants. One place to see every choice you made.

**Deliver in phases, not as one drop.** See the phase gates in the main brief. A single
large delivery of never-executed code is not reviewable and not runnable, and we will send
it back.
