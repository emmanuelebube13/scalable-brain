# OANDA v20 Data Contract

You do not have network access and cannot test any of this. The operator runs your scripts.
This document exists so you write against the real API rather than a plausible-looking one.

Anything marked **[VERIFY]** is our belief but not something we have re-confirmed recently —
write your code so that a wrong assumption fails loudly and immediately rather than
silently producing bad data.

## Access

- **Environment: practice.** Host `https://api-fxpractice.oanda.com`.
  (Live is `api-fxtrade.oanda.com`; we are not using it. Historical candle data is the same
  on both.)
- **Auth:** header `Authorization: Bearer <token>`.
- **Never hardcode the token or account ID.** Read them from environment variables. Your
  scripts must fail with a clear message if they are unset, and must never log or echo
  them. The operator will not paste credentials into any file you produce.
- Account ID is only needed for account/trading endpoints. Candle history does not require
  it — prefer the instrument-scoped endpoint that doesn't.

## The endpoint you need

```
GET /v3/instruments/{instrument}/candles
```

Query parameters that matter:

| Param | Notes |
|---|---|
| `granularity` | Exact strings. See table below. |
| `price` | `M` mid (default), `B` bid, `A` ask. **Combinable: `BA` returns both bid and ask candles in one response.** |
| `count` | Default 500, **maximum 5000**. |
| `from`, `to` | RFC3339 timestamps. |
| `includeFirst` | Whether the candle at `from` is included. Matters for pagination — see below. |
| `dailyAlignment`, `alignmentTimezone`, `weeklyAlignment` | See the alignment section. Critical for D and W. |

**You may not pass `count` together with both `from` and `to`.** Pick one pagination style:
`from` + `count` (walk forward), or `from` + `to` (bounded window). Mixing all three is an
error.

## Granularity strings — exact

`S5 S10 S15 S30 M1 M2 M4 M5 M10 M15 M30 H1 H2 H3 H4 H6 H8 H12 D W M`

Note: **daily is `D`, not `D1`.** Weekly is `W`, monthly is `M` — and `M` also means "mid"
in the `price` parameter. They are different parameters; do not let that collide in your
config schema.

## Alignment — the thing that quietly corrupts daily data

Defaults are `dailyAlignment=17`, `alignmentTimezone=America/New_York`,
`weeklyAlignment=Friday`. A "daily" candle therefore runs 17:00 NY to 17:00 NY, **and that
boundary shifts against UTC twice a year with US daylight saving.** If you request D
candles and assume UTC midnight boundaries, your daily bars are wrong and your daily
indicators are wrong with them.

Decide explicitly what alignment your system wants, set it explicitly rather than relying
on defaults, record the choice in your schema, and state the reasoning. If you resample
intraday bars into higher timeframes yourself instead of asking OANDA for them, the same
decision has to be made — just by you rather than by the API.

Also set the datetime format explicitly via the `Accept-Datetime-Format` header
(`RFC3339` or `UNIX`) rather than depending on the account default.

## Candle response — three traps

1. **`complete: false`.** The most recent candle in a response is usually still forming.
   Ingesting it produces a bar whose high/low/close will change on the next fetch. **Filter
   on `complete == true` at ingest.** This is the single most common way a price table
   becomes quietly inconsistent.
2. **`volume` is tick count, not traded volume.** It is a count of price updates. It is a
   legitimate feature but it is not FX volume in any economic sense, it is broker-specific,
   and its level is not comparable across eras as OANDA's feed changed. Use with care and
   say what you assume.
3. **Weekends and holidays produce genuine gaps, not missing data.** The FX week runs from
   roughly Sunday 22:00 UTC to Friday 22:00 UTC (shifting with DST — see alignment). A
   bar-count-based lookback silently spans a weekend; a time-based one does not. Decide
   which you mean. Also: OANDA returns **no candle at all** for periods with no ticks — the
   absence of a bar is not an error and your gap detection must distinguish "market closed"
   from "ingest failed".

## History depth

- Majors on H1 go back to roughly **2004–2005**. As a concrete calibration point: EUR_USD
  H1 has about **130,000 complete bars** in our existing store, which is ~21 years.
- Depth varies by instrument and granularity. **[VERIFY]** Do not assume a uniform start
  date across the seven — probe each one and record what you actually got.
- Sub-hourly history is shallower and heavier. If you want M15 or finer, probe first.

**Volume is not a real constraint here.** Seven instruments × H1 × 21 years is under a
million rows. Even M15 across all seven is a few million. This is small for PostgreSQL. Do
not artificially restrict your history depth on storage grounds — restrict it, if at all,
on the grounds that older data may not be representative of the market you intend to trade,
and argue that case explicitly if you make it.

## Rate limits and pagination

- Documented limit is around **120 requests/second per token** **[VERIFY]**. You will not
  need anything close to this. Pace conservatively (a few requests per second), back off
  exponentially on `429` and `5xx`, and make the pacing a config value the operator can
  lower without editing code.
- With `count` capped at 5000, a full H1 pull per instrument is ~26 requests. The entire
  seven-instrument multi-timeframe backfill is minutes of wall time, not hours.
- **Pagination must be resumable.** Assume the operator's connection will drop mid-backfill
  at least once. Checkpoint progress durably, make re-running the same command safe
  (idempotent upserts, not blind inserts), and make the resume path the default path rather
  than a special flag.
- Watch the boundary candle when walking `from` forward — depending on `includeFirst` you
  will either duplicate or skip one bar per page. Both are silent. Assert on it.

## Spread and transaction costs — a real decision, not a detail

`price=BA` returns **actual historical bid and ask candles**. That means the real,
time-varying, instrument-specific spread is available to you at every bar.

Our prior work did not use it. It assumed a flat 1.0 pip spread and 0.5 pip entry-only
slippage across all instruments and all eras. That is generous during liquid London/New York
hours and badly optimistic around the daily rollover, over weekends, on news, and during
2008 and 2015-style dislocations — which is exactly when breakout and reversal strategies
fire most.

You decide how to model costs. We only require that the decision is deliberate, documented,
and that your cost model is a swappable component so its sensitivity can be tested.

## What you cannot get from this API

**Historical financing/swap rates are not available through the candles endpoint.** For a
swing system holding positions across multiple days, overnight financing is a material and
persistently-signed component of P&L, not a rounding error — it can invert the sign of a
carry-adverse strategy's returns over a long sample.

We do not have a historical financing dataset. This is a genuine constraint, not a puzzle
with a hidden answer. Handle it however you judge best — approximate from interest-rate
differentials, bound the effect and show the result is robust within those bounds, restrict
to instruments where it is small, or something else. What we will not accept is silently
setting it to zero.

## The seven instruments

```
EUR_USD  GBP_USD  USD_JPY  AUD_USD  USD_CHF  USD_CAD  NZD_USD
```

This is the permitted universe. **You choose which of the seven to actually use and how far
back to go for each**, and you justify both. You are not required to use all seven.

Two things to know:

- `USD_JPY` is quoted to 3 decimal places with a pip of 0.01; the other six are quoted to 5
  decimals with a pip of 0.0001. Any code with a hardcoded `0.0001` is wrong for JPY. Get
  pip size and display precision from instrument metadata rather than assuming.
- These seven are not independent. USD is on one side of all of them, so a USD move shows up
  seven times. A portfolio that treats them as seven independent bets is overstating its
  diversification and understating its risk. Your portfolio construction and your
  significance testing both need to handle this.
