# The Six Strategies — Frozen Specification

This document defines the **object under test**. Six rule-based swing-trading concepts.

## How to read this document

Each strategy has three parts:

- **FROZEN — the concept.** The entry/exit *logic* is fixed. You may not change what the
  strategy is trying to capture, nor substitute a different indicator for the one named.
  If you believe a concept is unsound, say so in your method critique — do not silently
  replace it.
- **FREE — the configuration.** Every number, every timeframe, every instrument, every
  stop/target/holding rule, and all portfolio construction is yours to choose and justify.
  The parameters shown under "previously used" are *historical context only*. They are one
  arbitrary point in a large space and carry no authority. Do not anchor on them.
- **CAUSALITY REQUIREMENT.** Non-negotiable, applies to all six.

## The causality requirement (read this before anything else)

**Every quantity used to decide a trade at bar *t* must be computable using only bars at or
before *t*, using only information timestamped at or before the close of bar *t*.**

This has specific teeth for the pattern-based strategies below:

- A swing high/low, pivot, or divergence may only be **confirmed** once the bars to its
  right have actually occurred. A centred window (`rolling(center=True)`), a negative shift
  (`shift(-n)`), or any "find the local extreme" routine that inspects future bars is
  disqualifying. If confirming a swing requires *k* bars of right-hand context, the signal
  arrives *k* bars late, and that lateness is part of the strategy — not a detail to
  engineer away.
- Any normalisation, scaling, clustering, threshold, or quantile applied to a series must be
  fit on trailing data only. A quantile computed over the full series leaks the future into
  every bar.
- Instrument/timeframe/parameter selection made by looking at full-sample results is the
  same failure at a higher level. Your validation design must account for it.

Assume we will attempt to break this. Design so that it holds by construction rather than
by discipline, and tell us what structural mechanism enforces it.

---

## S1 — Trend: Moving-Average State Change with Trend-Strength Confirmation

**FROZEN.** Directional entries taken when a fast exponential moving average changes its
state relative to a slow exponential moving average (fast crossing from at-or-below to
above ⇒ long; the mirror ⇒ short), admitted only when a trend-strength filter (ADX)
exceeds a threshold at that bar. The premise: moving-average state changes are frequent and
mostly noise; a trend-strength gate is what separates the tradeable ones.

**FREE.** EMA periods; ADX period and threshold; whether to require alignment with a
higher-timeframe trend and how; entry timeframe; stop, target and trailing rules; maximum
holding period; whether an opposing state change forces an exit.

*Previously used, for context only: EMA 20/50 on H4 (10/20 on H1), ADX(14) > 25,
stop 1.5×ATR, target 2.5×ATR, optional H1 confirmation and D1 macro filter.*

---

## S2 — Trend: Channel Breakout with Trend-Strength Confirmation

**FROZEN.** Long when the close exceeds the highest high of the preceding N bars
(Donchian upper band, as of the prior bar); short on the mirror. Admitted only when a
trend-strength filter (ADX) exceeds a threshold. Entries are suppressed while the channel
is compressed — the premise is that a breakout out of an already-narrow channel is noise,
and the strategy wants breakouts that occur with the channel already wide.

Note the deliberate tension with S6, which wants the *opposite* precondition. Both are in
the library on purpose.

**FREE.** Channel period; ADX period and threshold; whether the trend-strength filter is
required at all; how "compressed" is defined and measured (**trailing windows only**);
entry timeframe; stop, target, trailing and time-stop rules; whether to trail on the
channel mid-line.

*Previously used, for context only: 20-bar channel on H4 (10 on H1), ADX(14) > 25,
compression = channel width below its trailing 50-bar 20th percentile, stop 1.5×ATR,
target 3.0×ATR, max hold 50 bars.*

---

## S3 — Range: Band Excursion Mean Reversion with Oscillator Confirmation

**FROZEN.** Counter-trend entries when price closes at or beyond a volatility band
(Bollinger, N-period MA ± k standard deviations) and an oscillator (RSI) simultaneously
confirms exhaustion — long at/below the lower band with RSI oversold, short at/above the
upper band with RSI overbought. The entry requires price to **cross into** the extreme
zone on this bar (it was not beyond the band on the prior bar), not merely to remain there.
The natural target is reversion toward the band mid-line.

**FREE.** Band period and standard-deviation multiplier; RSI period and thresholds; whether
the oscillator confirmation is required; whether to suppress entries during band
compression and how compression is defined (**trailing only**); whether to filter out
counter-trend entries against a higher-timeframe trend; timeframe; stop, target
(mid-band vs. opposite band vs. ATR multiple), time stop, and oscillator-based exits.

*Previously used, for context only: BB(20, 2.0), RSI(14) at 30/70, stop 1.5×ATR,
target 1.5×ATR, max hold 20 bars, suppressed when bandwidth below its trailing 50-bar
20th percentile.*

---

## S4 — Range: Oscillator Exhaustion Reversal

**FROZEN.** Reversal entries driven by a stochastic oscillator leaving an extreme zone:
long when %K crosses back up through the oversold level from below, short when %K crosses
back down through the overbought level from above, with the %K/%D relationship confirming
that momentum has turned in the signal's direction. The premise is momentum exhaustion in
range-bound conditions.

**A divergence variant is explicitly in scope and explicitly separate.** Enter long on
bullish divergence (price makes a lower low while the oscillator makes a higher low)
coinciding with the oscillator's upward exit from oversold; mirror for short.

> **Critical.** Our implementation of this divergence variant located swing points with a
> centred window and was therefore reading five bars into the future. It was the only
> strategy that ever passed our qualification bar, and computed honestly it emits **zero**
> signals. Treat this as a live trap, not a footnote. If you implement the divergence
> variant, swing confirmation must be strictly causal — which means signals arrive after
> the right-hand bars exist — and you should expect its behaviour to differ completely from
> anything our history suggests. Whether the honest version has any edge is genuinely
> unknown to us; we have never measured it.

**FREE.** %K and %D periods and smoothing; oversold/overbought levels; whether %K/%D
confirmation is required; the causal swing-confirmation rule and its lag; the divergence
lookback and what counts as a comparable prior swing; timeframe; all exit and risk rules.

*Previously used, for context only: %K 14, %D 3, smoothing 3, levels 20/80,
stop and target 1.5×ATR, max hold 15 bars.*

---

## S5 — Structure: Support and Resistance Price Action

**FROZEN.** Levels are derived from historical swing highs and lows, clustered so that
nearby swings collapse into a single level, and scored by how many times price has touched
them. Two entry modes, both in scope and to be evaluated separately:

- **Bounce.** Long when price is at an established support level and the bar closes
  bullish (close above open); short at resistance with a bearish close. Requires the level
  to have at least a minimum number of touches, and requires room to the opposing level.
- **Break.** Long when price closes through a previously-established resistance level that
  it had not closed through on the prior bar; mirror for short. Requires the level to have
  met the same touch-count bar before it broke.

**CAUSALITY — this strategy is where our implementation failed.** Our swing detection used
the same centred-window pattern as S4. Levels must be built only from swings confirmed by
bars at or before the decision bar, and the touch count for a level may only count touches
that had already occurred. A level's strength is a trailing quantity.

**FREE.** Swing confirmation rule and lag; clustering tolerance; lookback window for level
construction; minimum touch count; how "at" a level is defined (absolute distance, ATR
multiple, percentage); the room-to-opposing-level requirement; timeframe; stop placement
(level invalidation vs. ATR), targets, time stops.

*Previously used, for context only: swing period 5 on H4 (3 on H1), 50-bar level lookback,
0.1% clustering tolerance, minimum 2 touches, "at level" = within 0.5×ATR, required
opposing level more than 1×ATR away, stop 1.0×ATR, target 2.0×ATR, max hold 20 bars.*

---

## S6 — Volatility: Contraction-Then-Expansion Breakout

**FROZEN.** A volatility-contraction pattern followed by a directional breakout. Three
components in sequence: (1) volatility contracts — measured as current normalised ATR
falling below a fraction of its own trailing average, and/or the trading range narrowing
against its trailing average; (2) that contraction persists for a minimum number of bars;
(3) price then breaks out of the contraction range, in the direction of the prevailing
trend, with a trend-strength filter confirming. The premise is that compressed volatility
stores energy that releases directionally.

This is the deliberate inverse of S2's compression suppression. Which premise survives
honest measurement — if either does — is part of what we want to learn.

**FREE.** Contraction measure and threshold; minimum contraction duration; how recently
the contraction must have ended for a breakout to still count; breakout definition; trend
direction filter; trend-strength period and threshold; timeframe; stop, target, trailing
and time-stop rules. An "early entry" variant that enters on the first sign of expansion
rather than waiting for the full breakout is in scope as a separate variant.

*Previously used, for context only: 20-bar VCP period on H4 (10 on H1), contraction
threshold 0.5 on both the ATR and range measures, minimum 5 contraction bars, breakout of
the 20-bar Donchian band, EMA 20/50 for direction, ADX(14) > 20, stop 1.0×ATR,
target 4.0×ATR, max hold 30 bars.*

---

## What is NOT frozen

To be explicit, because we would rather you use this freedom than not:

- Which of the seven instruments each strategy trades, if any.
- Which timeframe(s) each strategy runs on. Prior work only ever tested H1 and H4 with a D1
  filter. Whether that was the right choice for a swing system was never established.
- Every numeric parameter.
- All exit, stop, target, trailing and holding-period logic.
- Position sizing and portfolio construction across strategies and instruments.
- Whether a strategy trades long only, short only, or both.
- Whether a strategy is worth including at all — a reasoned "S5 cannot be made causal in a
  way that preserves its premise" is a legitimate and useful finding.
