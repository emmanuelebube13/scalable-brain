# What Has Gone Wrong Before

This is a record of failures from roughly two years of building a system that attempts what
we are now asking you to attempt.

**It is deliberately written as symptoms, not diagnoses.** In most cases we know exactly what
the technical cause was and exactly how we patched it. We are withholding that on purpose.
We do not want your architecture to be ours with the known bugs removed — we want to find
out what a system designed from first principles does about these failure *classes*, and
whether it prevents them structurally rather than patching them after the fact.

If you find yourself asking "what did they actually do about #3", the answer is: it does not
matter, and we would rather you didn't guess. Design for the symptom.

---

## The failures

**1. The only strategy that ever passed our bar could not be traded.**
Out of a library of strategies and a four-state regime map, exactly one cell family
qualified for live capital. It scored excellently on every criterion we applied. It later
turned out that its entry condition was not computable at the moment it claimed to fire; it
depended on information that did not exist yet. Computed
honestly it produces no signals at all, ever. Everything downstream of it — the regime map,
the weights, the machine-learning layer trained on its outcomes, and a performance benchmark
we had already sent to a partner system — was void.

The part that we found most instructive: our selection process did not admit this strategy
*despite* the flaw. It admitted it *because* of the flaw. The flaw was the only thing that
lifted any candidate over the bar. A selection mechanism searching over a library will
preferentially surface whichever member has the largest measurement error, and it will
present that to you as your best result.

**2. Removing the flaw left us with nothing, and we had no plan for that.**
With that one strategy excluded, no remaining candidate cleared more than half of our
qualification criteria, and the shortfalls were not marginal. We had built an entire
downstream apparatus — attribution, machine-learning gatekeeping, artifact publishing,
execution, risk — on the assumption that qualification would produce a non-empty set. We had
never asked what the system should do, or what it would mean, if the honest answer was
"none of these work."

**3. We spent months building a regime layer that turned out not to discriminate.**
Regime detection was a centrepiece: classify market conditions, then route strategies to the
conditions where they perform. When we finally measured whether strategies actually behaved
differently across the regimes we had defined, the answer was that essentially none of them
did — the spread in performance across regimes was smaller than our own threshold for
calling it real. The regime map was decorative. It had been feeding decisions for a long
time before anyone measured whether it carried information.

**4. Our measurement code was wrong, and we blamed the gates.**
For a long period no strategy could qualify. The working assumption was that our thresholds
were too strict, and there was real pressure to relax them. The actual cause was arithmetic
errors in how two of the headline metrics were computed. We came close to loosening the
standards to accommodate a bug. Nobody had thought to test the measuring instrument.

**5. Pipelines died silently and kept reporting success.**
Two examples of the same class. Price ingestion stopped working and nobody noticed for over
two weeks — the system continued to run, retrain, and publish, on data that stopped moving.
Separately, the process that generated trade outcomes was broken for months by something
trivial and structural; every subsequent retrain silently re-derived its conclusions from
stale inputs and reported a clean run each time. In both cases every status indicator was
green. Failure was invisible because absence of new data is indistinguishable from absence
of change unless something is explicitly watching for it.

**6. Multiple things claimed to be "the current model".**
At various points we had more than one pointer file claiming to identify the live artifact,
one of which had been stale for weeks while being read as authoritative; a local copy and a
remote copy that disagreed; and two independent training paths writing to the same
destination, one of which was a known-contaminated legacy implementation that could
overwrite the good one. Every one of these was discovered by accident.

**7. Allocation logic destroyed merit.**
A weight-normalisation step drove the lowest-ranked qualifying strategy in each group to
effectively zero weight regardless of its actual performance — one strategy that ranked
strongly on every criterion we used received a weight of 8 × 10⁻⁸. Elsewhere, two entries
sharing an identifier caused their weights to merge silently instead of raising an error.
The allocation layer was treated as plumbing and reviewed as plumbing, while it was quietly
making the most consequential decisions in the system.

**8. Everything concentrated into one bet and we called it a portfolio.**
The final live configuration was a single strategy at a single timeframe. Of four regimes,
one had no qualified strategy at all — the system had no defined behaviour for a market
state it had itself identified as important. And the best-performing regime cell turned out
to be composed almost entirely of a single currency pair, in conditions that were not
practically tradeable. Each of these was visible in the outputs for a long time before
anyone connected them.

**9. Our cost assumptions were optimistic exactly where it mattered.**
Backtests assumed a flat spread and small fixed slippage across all instruments and all
market conditions, including the periods of dislocation when breakout and reversal
strategies fire most and when real costs are worst. Overnight financing on multi-day holds
was not modelled at all.

**10. The system outgrew anyone's ability to hold it in their head.**
It grew to eight layers, then was reorganised into three systems across three machines. For
extended periods the documentation described a runtime that no longer existed, retired code
sat beside live code, and answering "what actually runs" required archaeology. Several of
the failures above survived as long as they did because the system was too large to audit
and nobody could say with confidence which parts were load-bearing.

---

## The pattern, stated honestly

We did respond to each of these. We added default-safe behaviour so that missing or stale
inputs cause rejection rather than silent continuation; artifact integrity checks; single
ownership of destinations that had had multiple writers; safe-by-default execution modes; a
register of known defects; and regression tests that encode each past failure so it cannot
recur.

That is a decent list, and every item on it was added *after* the failure it addresses. The
meta-problem is not any individual bug. It is that **in every single case, the flaw was
discovered after it had already influenced a decision** — sometimes long after, occasionally
only when a downstream consumer asked a question we couldn't answer. Our detection was
always downstream of the consequence. The system was very good at producing confident
outputs and very bad at telling us when it had no business being confident.

There is a second pattern worth naming. Several of these failures share a shape: **a
mechanism that searches over options will find the option with the largest error and present
it as the winner.** Look-ahead selected our one qualified strategy. Metric bugs shaped which
gates seemed too strict. Regime routing conditioned on a signal that turned out to be noise.
When you build any layer that selects, ranks, or optimises, assume it is hunting for your
mistakes and will find them faster than you will.

---

## What we want from you regarding all of this

Not fixes to our bugs — a design in which these classes of failure are structurally hard.
In your architecture document, address directly:

- How does your design make non-causal computation impossible rather than merely
  discouraged, and how would you *prove* that to a sceptic who assumes you got it wrong?
- How does your system distinguish "no edge exists" from "the pipeline is broken" from "the
  data stopped arriving"? All three produce flat results.
- What happens when your qualification step returns an empty set? Treat this as the expected
  outcome and design for it, not as an error case.
- Who validates the validator? What tests your metric calculations, your cost model, and
  your significance testing — given that a bug in any of them is invisible from the results?
- How does your selection layer avoid rewarding measurement error, given how many
  strategy × instrument × timeframe × parameter combinations you will evaluate?
- What in your design would tell you it had gone wrong *before* a decision was made on it,
  rather than after?

An architecture that has good answers to these and finds no tradeable edge is worth more to
us than one with a promising backtest and no answers.
