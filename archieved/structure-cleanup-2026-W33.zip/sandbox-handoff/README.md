# Sandbox Handoff — Operator Instructions

Everything needed to hand the strategy-qualification sandbox to the external agent team.
Created 2026-08-09.

## What this is

A controlled re-test of the core Scalable Brain method — regime-conditioned qualification of
a strategy library — rebuilt from first principles by an independent team, in a fresh
sandbox, with the six staged strategies as the frozen object under test.

The point is not to get the six strategies working. The 2026-08-02 look-ahead audit already
established that the honest library qualifies nothing. The point is to find out whether the
*method* can distinguish edge from artifact when built by someone with no access to our
assumptions, our metrics, or our results.

## What to upload

Upload these four files, then paste `PROMPT.md` as the message.

| Order | File | What it is |
|---|---|---|
| 1 | `uploads/01-strategy-specs.md` | The six strategies in English. Frozen logic, free configuration, causality requirement. |
| 2 | `uploads/02-oanda-data-contract.md` | OANDA v20 API facts, traps, the seven-instrument universe. |
| 3 | `uploads/03-runtime-environment.md` | Your machine, the database, and the no-execution model. |
| 4 | `uploads/04-failure-history.md` | Ten failure classes from two years, written as symptoms with no fixes. |
| — | `PROMPT.md` | Paste as the message body. |

All five are self-contained and contain no credentials, no account IDs, and no performance
numbers.

## What NOT to upload

- **Any of our source code.** Specifically not the six strategy `.py` files. Two of them
  (`range_stochastic.py`, `support_resistance.py`) contain the centred-window look-ahead;
  sending them would hand over the exact bug we want to see whether an independent design
  avoids. The English specs already encode the causality requirement.
- **The regime module — not yet.** It goes over at the Phase 3 gate, deliberately, so their
  design is independent first. List below.
- **Anything with results in it.** No `regime_strategy_map.json`, no `strategy_weights.json`,
  no attribution outputs, no qualification reports. This is the blind protocol; a single
  leaked metric compromises it.
- **`.env`, `secrets/`, any token, the OANDA account ID, GCP credentials.**
- Our gate thresholds and metric definitions. Deliberately absent from all four documents.

## Send at the Phase 3 gate — not before

Once they have delivered their own market-condition design:

- `scalable-brain/src/system1/regime/hmm_regime.py`
- `scalable-brain/src/system1/regime/mapping.py`
- `scalable-brain/src/system1/regime/schema.py`
- `scalable-brain/docs/proposed-fixes/system-1/FIX-S1-003-regimes-do-not-discriminate.md`
- `scalable-brain/docs/proposed-fixes/system-1/FIX-S1-005-regime-labels-non-causal-leakage.md`
- `scalable-brain/results/reports/regime_discrimination_20260724T083739Z.json`

Ask me to sanitise these before you send them — I'll check for anything that leaks a
performance number or a credential.

## How the loop runs

1. They deliver a phase.
2. You paste it to me (or drop the files somewhere I can read them). **I cross-check
   statically — I will not run their code.** I look for look-ahead, SQL errors, API misuse,
   schema mismatches, unit errors, blind-protocol violations, and anything unsafe.
3. I give you the exact commands to run, in order, with what to expect.
4. You run them and send me the output.
5. I tell you what to send back to the agents — **structural diagnostics only**. If a
   performance number appears in the output, it stops with you and me.
6. Next phase.

**You are the only person who sees results.** That is the whole design. If something
performance-related does get through to them, tell me and we log it as a contamination event
rather than pretending it didn't happen.

## Before Phase 1 runs

Two things you'll need on your machine, which I'll give you exact commands for when their
migrations arrive:

- A **separate database** on the existing PostgreSQL cluster. Their scripts are instructed
  never to touch `ForexBrainDB` and to refuse to run if pointed at it, but the isolation
  should be real, not just requested.
- A **dedicated virtualenv** for the sandbox, separate from
  `/home/emmanuel/Documents/Scalable_Brain/.venv`, so their pinned dependencies can't disturb
  System 1.

Your OANDA token and the sandbox database credentials go in a local `.env` that you create
from their `.env.example`. Nothing they produce should ever contain the values.

## The one thing to watch for

The agents are instructed to expect a negative result and to treat "nothing qualifies" as a
complete deliverable. If a phase comes back with an encouraging result and the accompanying
methodology is thin — small trade counts, no multiple-comparison correction, an optimistic
cost model, or parameter selection sitting outside the out-of-sample structure — that is the
same failure that cost us two years, arriving in new clothes. Send it to me before you
believe it.
