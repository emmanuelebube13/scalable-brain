# Prompt: Design the Strategy Research Engine

You are designing a strategy research engine for a swing-trading system. Read the
requirements below and propose your own approach. Do not assume any particular
implementation — think from first principles.

## Context

This system currently has:

- A backtest engine that runs any strategy on 5 years of historical price data across 5
  forex pairs and 3 timeframes (H1, H4, D1).
- A vetting system with hard gates (Profit Factor >= 1.5, Sharpe >= 0.8, Max Drawdown <= 25%,
  Win Rate >= 40%, Recovery Factor >= 3.0, 60 months minimum out-of-sample history).
- A promotion pipeline that publishes strategies that pass all gates into the live trading
  system.
- A strategy library of 18 hand-coded strategies across 6 families (trend-following,
  mean-reversion, breakout).

The problem: the strategy library is static. There is no way to discover new strategies from
outside the codebase. All 18 strategies were written by hand and never change.

## The Goal

Build an engine that can:

1. Pull in trading strategy ideas from any external source.
2. Test each idea against historical data.
3. Either promote it into the live system or reject it with a clear documented reason.
4. Do this on a recurring schedule without human intervention.
5. Keep a permanent record of every strategy ever tested and its outcome.

## The Questions You Need To Answer

Answer each question in your own words. Describe the approach you would take and why.

### A. Sources

What external sources should this engine pull from? What kinds of inputs would produce the
most useful strategies? How would you parse each type of input into something the backtester
can run?

### B. Translation

The backtester expects a Python class with entry/exit/risk logic. How do you convert an idea
from an external source into that format? What if the idea is only described in plain English?

### C. Quality Control

How do you prevent garbage strategies from flooding the system? What safeguards exist beyond
the existing vetting gates? What if a strategy looks good on backtest data but is overfitted?

### D. Discovery

Beyond ingesting existing strategies from papers and blogs, how could the system discover
entirely new strategies it has never seen before? Are there ways to search the space of
possible trading rules algorithmically?

### E. Scheduling

How often should this engine run? What triggers a new discovery/ingestion cycle? How does it
coordinate with the existing System 1 weekly retrain that already runs on Sundays?

### F. Tracking

What should the permanent record of tested strategies contain? What would you want to know
when looking back at rejected strategies 6 months later?

### G. Risks and Failure Modes

What could go wrong? What are the ways this engine could produce bad results — promoting a
strategy that loses money, rejecting a good one, or degrading system performance?

## Constraints

- The engine lives inside an existing Python codebase using PostgreSQL, pandas, and
  scikit-learn.
- It must be testable without live market data.
- It must not break the existing weekly retrain cycle.
- Every decision (promote/reject) must be explainable — no black boxes.

## Deliverable

Produce a design document that answers all seven questions above. For each answer, explain
your reasoning. If you are uncertain about a trade-off, state the options and what you would
need to know to decide.
