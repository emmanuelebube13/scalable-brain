# Strategy Research Engine — Design Document

**Status:** Proposal (answers plans/02-llm-prompt-research-engine.md)
**Date:** 2026-07-10
**Scope:** System 1 (The Brain). No changes to System 2 execution or System 3 AMS.

---

## The Central Design Decision (read this first)

Everything below follows from one choice: **external ideas are never translated
directly into Python code. They are translated into a constrained, declarative
Strategy Spec (a small DSL), and one trusted compiler turns specs into
`StrategyBase` subclasses.**

Why this is the load-bearing decision:

1. **Explainability (hard constraint).** A spec is a data structure — "entry:
   close crosses above donchian_high(20) AND adx(14) > 25" — that a human can
   read in ten seconds. Arbitrary generated Python is a black box you have to
   audit line by line. The constraint "every decision must be explainable"
   applies to the strategy itself, not just the promote/reject verdict.
2. **Safety.** The engine runs unattended. Executing code authored by an LLM,
   scraped from a blog, or evolved by a genetic algorithm is an unacceptable
   attack/bug surface. Executing a spec through one hand-written, well-tested
   compiler is not.
3. **Searchability.** Question D (algorithmic discovery) becomes tractable: a
   genetic algorithm can mutate and crossbreed spec trees. It cannot sanely
   mutate Python source.
4. **Deduplication.** Two specs can be compared structurally and their signal
   series compared numerically. Two blobs of Python cannot.
5. **Lookahead safety.** The compiler is the *only* place indicator computation
   happens, so lookahead bias (using `shift(-1)`, centering windows, peeking at
   the current bar's close for the current bar's entry) is prevented once, in
   one place, rather than re-audited per strategy.

The cost: **expressiveness**. Some ideas (order-book logic, news-event logic,
multi-leg options) cannot be expressed in the DSL. That is acceptable — the
existing 18 strategies are all indicator-threshold-crossover strategies over
OHLC bars, so the DSL only needs to cover that family generously. An idea that
can't be expressed is *rejected with reason `NOT_EXPRESSIBLE`*, which is a
documented outcome, not a failure of the engine.

### The Strategy Spec, concretely

A JSON/YAML document validated against a schema:

```yaml
name: donchian_break_adx_filter
family: breakout
direction: both              # long | short | both
entry:
  all:
    - cross_above: [close, donchian_high(20)]
    - gt: [adx(14), 25]
exit:
  any:
    - trailing_stop: {atr_mult: 2.0, atr_period: 14}
    - cross_below: [close, ema(50)]
risk:
  stop_loss: {atr_mult: 2.0}
  position_size: fixed_fraction   # sizing stays owned by the platform, not the spec
constraints:
  timeframes: [H4, D1]
  warmup_bars: 60
provenance:
  source: "ssrn:4123456"
  extracted_by: "llm-translator v3"
  raw_text_hash: "sha256:..."
```

The vocabulary is closed: ~25 indicators (exactly what `layer0/indicators.py`
already computes), 8 comparison/crossover operators, boolean `all`/`any`/`not`,
4 exit types (ATR stop, trailing stop, opposite-signal, time stop), numeric
parameters with schema-enforced bounds (e.g. lookbacks 2–400). The compiler
emits a `StrategyBase` subclass implementing `calculate_indicators`,
`generate_signals`, `get_entry_conditions`, `get_exit_conditions`,
`get_required_warmup_bars` — the exact interface the 18 hand-coded strategies
already use, so the existing backtester and promotion pipeline need **zero
changes** to run a discovered strategy.

Grow the vocabulary deliberately: when a genuinely good idea is rejected as
`NOT_EXPRESSIBLE`, that's the signal to add a primitive (by hand, with tests),
not to loosen the wall.

---

## A. Sources

Rank sources by **signal-to-noise per unit of engineering effort**, and be
honest that the ranking is roughly the reverse of how exciting they sound.

### Tier 1 — the system's own material (highest yield, build first)

1. **Parameter-space expansion of the existing 6 families.** The 18 strategies
   are points in a much larger space (Donchian 20 exists; 10/55/100 don't; the
   ADX filter exists on EMA but not on Bollinger). This source needs no parsing
   at all — the "external input" is a generator that emits spec variants. It
   will produce the first hundred candidates and shake out the whole pipeline
   before any scraping code exists.
2. **Cross-family recombination.** Entry block from one family, exit block from
   another (Donchian entry + Bollinger-band-touch exit). Again pure spec
   manipulation, no parsing.

### Tier 2 — curated external text (moderate yield, moderate effort)

3. **Academic papers** (SSRN, arXiv q-fin, Journal of Trading reading lists).
   Best idea density because they state rules precisely and often include
   out-of-sample results. Parsing: PDF → text extraction → LLM translation to
   spec (Section B). Pull from RSS/API feeds on keywords (momentum, carry,
   mean-reversion, FX).
4. **Public strategy code** — TradingView Pine Script, QuantConnect/backtrader
   repos. Semi-structured: Pine's `ta.crossover(ema(9), ema(21))` maps nearly
   1:1 onto DSL operators. Parse with a small Pine-subset parser for the common
   80%; fall through to LLM translation for the rest.
5. **Blogs / forum posts / books in plain English.** Lowest precision, highest
   volume, heavy survivorship bias (people publish winners). Ingest, but
   expect and log a high rejection rate — the pipeline's job is precisely to
   be the filter these sources lack.

### Tier 3 — generative (unbounded volume, needs the strictest QC)

6. **LLM-generated ideas** ("propose 10 mean-reversion variants for FX H4 that
   differ structurally from these existing specs: …"). Cheap and infinite,
   which is exactly the danger — see multiple-testing in Section C. Useful
   mainly as a mutation operator for the discovery loop (Section D), not as a
   trusted idea source.
7. **Algorithmic search** (Section D) — technically a source, treated
   separately.

**What I would *not* ingest:** live social-media signals, paid signal services,
competition leaderboards without published rules. If the rules aren't stated,
there is nothing to translate — only a curve to imitate, which is overfitting
by construction.

**Uniform parsing model:** every source adapter has one job — produce
`(spec_candidate, provenance, raw_source_hash)`. Adapters never touch the
backtester. This keeps sources pluggable: a new source is one new adapter class
and zero changes downstream.

---

## B. Translation

Three lanes, by input type:

1. **Structured (generated/mutated specs):** already in DSL form. No
   translation.
2. **Semi-structured (Pine Script, simple code):** deterministic parser for the
   supported subset. Deterministic wins over LLM here because it's free,
   reproducible, and its failures are loud (parse error) rather than quiet
   (plausible-but-wrong spec).
3. **Plain English (papers, blogs):** an LLM **translator, never an author**.
   The prompt gives the DSL schema and the source text and asks for a spec *or*
   an explicit `NOT_EXPRESSIBLE` refusal. Temperature 0, schema-validated
   output, retried once on validation failure, then rejected.

### Defending against mistranslation (the real risk in lane 3)

An LLM that flips a `>` into a `<` produces a runnable, plausible, wrong
strategy. Mitigations, in order of value:

- **Round-trip verification.** A *second, independent* LLM call renders the
  spec back into English; a third call (or embedding similarity + key-fact
  checklist: direction, indicator names, thresholds, stop type) judges whether
  it matches the source text. Disagreement → flag `TRANSLATION_UNCERTAIN`,
  quarantine for the human review queue rather than auto-test.
- **Schema bounds catch nonsense** (RSI threshold of 250, lookback of 0).
- **The spec is stored alongside the source text hash forever**, so any later
  suspicion ("this paper strategy performs suspiciously unlike the paper") can
  be audited by a human in minutes.
- **Prompt-injection defense:** ingested text is untrusted input. The
  translator prompt treats source text strictly as data; the output can only
  ever be a spec (which cannot contain code), so the blast radius of a
  malicious document is one garbage candidate that then has to survive the
  entire vetting funnel. This is a second, independent payoff of the
  no-generated-code rule.

If the idea genuinely can't fit the DSL: reject as `NOT_EXPRESSIBLE`, store the
source and the translator's explanation of *what* was inexpressible. That log
is the roadmap for DSL vocabulary growth.

---

## C. Quality Control

The existing gates (PF ≥ 1.5, Sharpe ≥ 0.8, MaxDD ≤ 25%, WR ≥ 40%, RF ≥ 3.0,
60 months OOS) were designed for **18 hand-written strategies**. Point an
automated generator at them and they will be Goodharted by volume: test 10,000
random strategies and some will pass every gate by pure luck. So QC is a
**funnel with a multiple-testing correction at the end** — the gates stay as
they are, but they stop being the last word.

### The funnel (cheap → expensive)

1. **Schema validation** — free. Malformed specs die here.
2. **Structural dedup** — free. Canonicalize the spec (sorted conditions,
   normalized parameter representation), hash it, reject exact repeats. The
   permanent record (Section F) makes this trivially a DB lookup.
3. **Behavioral dedup** — cheap. Run on one pair/one timeframe/one year;
   compute signal-series correlation against every live strategy and every
   previously *promoted or incubating* candidate. Correlation > ~0.9 → reject
   as `DUPLICATE_BEHAVIOR` with the twin's ID. This is also the crowding
   defense: 12 "different" trend strategies that fire on the same bars are one
   leveraged bet, not diversification.
4. **Sanity backtest** — cheap. One pair, one TF, two years. Kill anything with
   < 30 trades (nothing to measure), PF < 1.0 (worse than random after costs),
   or > 40% drawdown. Expect this stage to remove most of the volume so stage
   5 stays affordable.
5. **Full walk-forward backtest** — expensive. All 5 pairs × 3 timeframes,
   full history, realistic spread/slippage, anchored walk-forward. Existing
   engine, unchanged.
6. **Existing vetting gates** — unchanged, on the walk-forward OOS segments.
7. **Anti-overfit battery** (new, the heart of this design):
   - **Untouched holdout.** Reserve the most recent ~12 months of data that
     *no* stage 1–6 ever sees — not the generator, not the GA fitness
     function, not the gates. A candidate that passes the gates must also be
     merely *not-bad* on the holdout (PF > 1.0, no gate catastrophically
     violated). The holdout answers one question the gates can't: "did this
     strategy ever see this data during its own selection?" For discovered
     strategies the answer must be provably no.
   - **Deflated Sharpe ratio / White's Reality Check.** The gate threshold for
     a candidate must account for **N = how many candidates have been tried
     from the same search process**. This is *why the permanent record is a
     correctness requirement, not bookkeeping*: N comes from the database.
     Testing 1,000 candidates and applying a Sharpe ≥ 0.8 gate designed for
     N = 18 is statistically indefensible.
   - **Parameter-plateau test.** Perturb every numeric parameter ±10–20% and
     re-run stage 4. A robust strategy sits on a plateau (metrics degrade
     gracefully); an overfit one sits on a spike (falls apart). Reject spikes
     as `PARAMETER_FRAGILE`. Cheap relative to its value.
   - **Trade-sequence Monte Carlo.** Reshuffle/bootstrap the trade list; if the
     5th-percentile equity path breaches the MaxDD gate, reject as
     `LUCK_DEPENDENT_PATH`.
8. **Incubation (paper phase).** Nothing goes from backtest straight to live
   money. Gate-passers enter `INCUBATING`: tracked on new incoming data
   (paper, or the smallest permitted live size) for a fixed window — e.g. 8–13
   weeks or ≥ 30 trades, whichever is later. Promotion to live requires
   incubation PF > 1.0 and behavior statistically consistent with backtest
   expectations (trade frequency, average win/loss within confidence bands —
   a strategy that trades 5× more often live than in backtest has a bug, even
   if it's profitable). Incubation is the only true out-of-sample test that is
   *guaranteed* untouched by any search process, because the data didn't exist
   yet.

### Rate limiting

A hard cap on candidates entering stage 5 per week (compute budget) and on
promotions per month (e.g. max 2). Slots go to the highest stage-4 scores. The
live book changing slowly is a feature: it keeps System 3's risk picture
interpretable and bounds the damage of any single bad promotion.

**Open trade-off:** holdout size. 12 months of holdout weakens the 60-month OOS
gate's data; 6 months is a weak holdout. I'd start with 12 and revisit once we
see how many candidates die at the holdout stage — if none do, the earlier
stages are doing their job and the holdout can shrink. Deciding properly needs
the empirical stage-by-stage kill rates, which only running it produces.

---

## D. Discovery

Ingestion finds strategies *someone already wrote*. Discovery searches the
space of strategies *nobody has*. The DSL makes this concrete: the search space
is the space of valid spec trees, which is large but structured.

Three mechanisms, in build order:

1. **Systematic parameter/structure sweep (build first).** Enumerate
   neighborhoods around the 18 existing strategies: parameter grids, filter
   swaps, exit swaps, timeframe moves. Boring, bounded (thousands, not
   billions), and every result is interpretable as "existing family + one
   change." Most of the near-term real gains live here, because the 6 families
   are already known to contain viable strategies.
2. **Typed genetic programming over spec trees (the main event).**
   - *Representation:* the spec tree itself. Typed GP so mutation/crossover can
     only produce schema-valid trees (an operator expecting a price series
     can't receive a boolean).
   - *Operators:* mutate a parameter, swap an indicator for a same-typed one,
     graft an entry subtree from one individual onto another, add/remove a
     filter condition. Seed generation 0 with the 18 existing specs plus
     Tier-2 ingested specs — start from known-viable regions, not random noise.
   - *Fitness:* evaluated on the **training segment only** — a gate-aligned
     composite (Sharpe, PF, DD) **minus an explicit complexity penalty** (per
     node in the tree). Parsimony pressure is the single most important
     anti-overfit lever inside the GA: without it, evolution reliably produces
     30-condition monsters that memorize the data.
   - *Selection across generations:* on a **separate validation segment**, so
     the GA can't overfit its own fitness data.
   - *Final judgment:* survivors enter the Section-C funnel at stage 3 like any
     other candidate — including the untouched holdout **which the GA has
     never seen at any stage**. This three-way split (fitness / selection /
     holdout) is non-negotiable; collapse any two and the GA's output is
     unfalsifiable.
   - *N accounting:* every individual ever evaluated increments the
     multiple-testing counter. A GA evaluates tens of thousands of candidates;
     the deflated-Sharpe correction must know that.
   - *LLM as smart mutation:* occasionally ask an LLM to propose a
     domain-informed variation of a promising spec ("this breakout works on D1
     but fails on H1 — propose a volatility filter"). Structurally it's just
     another mutation operator whose output is schema-validated like all the
     rest — creativity without any code-execution trust.
3. **Gap-driven generation (later).** Analyze the *live portfolio's* residual:
   which market conditions do the current strategies collectively sit out or
   lose in? Direct search toward specs whose signals are *uncorrelated* with
   the existing book by adding a decorrelation term to GA fitness. This
   optimizes what actually matters — marginal portfolio value — rather than
   standalone metrics.

**One caution from this system's own history:** FIX-S1-003 showed that regime
labels do *not* discriminate strategy performance here (0/10 strategies, even
over trade-life windows). So regime-conditioning should **not** be a search
dimension in v1 — it would add a large chunk of search space that the system's
own evidence says is currently dead weight.

---

## E. Scheduling

Different pipeline stages have different natural cadences; forcing one clock
onto all of them is the mistake to avoid.

| Stage | Cadence | Why |
|---|---|---|
| Source ingestion (adapters) | Daily, off-peak | Cheap I/O; papers/blogs trickle in continuously |
| Translation + stages 1–4 (cheap funnel) | Continuous queue worker, budgeted | Keeps the expensive weekly batch fed |
| Discovery (GA / sweeps) | Weekly batch, mid-week (e.g. Wed) | Expensive; maximal distance from Sunday retrain |
| Full backtest + gates + anti-overfit (stages 5–7) | Weekly batch, completes by Saturday | Produces the week's verdicts |
| Promotion to incubation / rejection | **Sunday, immediately after System 1 retrain completes** | See below |
| Incubation → live promotion review | Sunday, same boundary | Same |

### Coordination with the Sunday retrain (the constraint that matters)

The existing weekly retrain is the system's heartbeat and the constraint says
don't break it. Two rules enforce that:

1. **The research engine never writes to live configuration mid-week.** All
   verdicts land in its own tables in a `staged` state. The strategy set that
   System 1's retrain and Layer 2 see is immutable between Sundays. This also
   avoids the class of drift bug already seen in this system (Layer 2 config
   drifting from Layer 0 qualification — the 2026-07-04 re-sync): one writer,
   one write-window.
2. **Sequencing within Sunday:** retrain runs first on the stable strategy
   set; the promotion step runs *after* it completes (triggered by the
   retrain's completion event/sentinel, not by wall-clock — a slow retrain
   must delay promotion, never overlap it). Newly promoted strategies
   therefore take their first live effect the *following* week with a full
   retrain behind them. Rationale for retrain-first: the retrain is the
   revenue-critical path and gets the stable input; promotion is the
   experimental path and can always wait a week. Also namespace all research
   artifacts (`research/…` in the DB schema and model registry) — this system
   has already had two trainers colliding on `models/champion_*`; don't create
   a third writer to shared paths.

Event triggers *fill queues* (new paper found → translation queue); only the
scheduled batches *drain* them into decisions. No decision is ever made outside
the Sunday window. This makes the whole system's weekly state transition
auditable as a unit.

**Testability without live data** (hard constraint): every stage reads from
the historical Postgres price store; incubation in test mode replays a held
"pseudo-live" slice through the same code path that live incubation would use.
The full pipeline — ingest → translate → funnel → verdict — runs end-to-end in
CI against fixture data with a frozen clock.

---

## F. Tracking

The record is append-only and serves four masters: the multiple-testing
counter (correctness), dedup (efficiency), explainability (constraint), and
future re-evaluation (opportunity). PostgreSQL, four tables:

```
research.candidates
  candidate_id, spec (JSONB), spec_canonical_hash (UNIQUE),
  family, source_type, provenance (JSONB: URL/DOI/prompt, raw_text_hash,
  translator version, round-trip verdict), created_at,
  parent_candidate_id (GA lineage / "variant of" links)

research.evaluations            -- one row per candidate per stage per attempt
  evaluation_id, candidate_id, stage, started_at,
  code_version (git SHA of engine+compiler), data_window,
  cost_model (spread/slippage assumptions),
  metrics (JSONB: every gate input + per-pair/TF breakdown),
  artifact_path (equity curves, trade lists — GCS/disk, referenced not embedded)

research.verdicts               -- append-only; new verdict supersedes, never updates
  verdict_id, candidate_id, verdict
    (REJECTED | INCUBATING | PROMOTED | RETIRED | QUARANTINED),
  reason_code (NOT_EXPRESSIBLE | DUPLICATE_BEHAVIOR | GATE_FAIL_SHARPE |
    PARAMETER_FRAGILE | HOLDOUT_FAIL | INCUBATION_DIVERGED | ...),
  reason_text (one human paragraph, mandatory),
  gate_values_at_decision (JSONB), n_candidates_tested_at_decision,
  decided_at, decided_by (pipeline version)

research.incubation_log
  candidate_id, week, paper_metrics (JSONB),
  divergence_from_backtest_expectation
```

Design points:

- **`reason_text` is mandatory and human-written-quality.** "Sharpe 0.71 vs
  gate 0.8; deflated threshold was 1.05 given N=3,400 tested this quarter;
  failed on GBP pairs specifically" — that sentence is the explainability
  constraint made concrete.
- **`n_candidates_tested_at_decision`** snapshots the multiple-testing state,
  so any verdict can be re-derived later.
- **Verdicts are append-only.** A candidate's history (rejected 2026-07 →
  re-evaluated 2027-01 → incubating) is itself data.

### The 6-months-later questions, and what answers them

| Question | Answered by |
|---|---|
| What exactly was this strategy? | `spec` — readable, complete, no code archaeology |
| Why exactly did it fail? | `reason_code` + `gate_values_at_decision` (failed by 0.09 ≠ failed by 3.0) |
| Would it pass on today's data? | Re-run the spec: engine version pinned, spec immutable → one command |
| Did we reject it for reasons that no longer hold? | Compare `code_version`/`cost_model` — if a metrics bug was since fixed (this system has had exactly that: the Sharpe/MaxDD bugs in metrics.py), every verdict from the buggy version is queryable and re-runnable |
| Are we rejecting whole families systematically? | Aggregate `reason_code` × `family` — if all mean-reversion dies at the same gate, the gate or cost model deserves scrutiny |
| Did rejected strategies go on to "work"? | **Shadow-tracking**: keep computing paper metrics for near-miss rejects (failed exactly one gate by <10%). This is the engine's own false-negative measurement — the only empirical answer to "are the gates too strict?" |

That last row deserves emphasis: this codebase already lived the failure mode
where qualification was blocked by *measurement bugs* rather than strategy
quality. A permanent, re-runnable record is what makes that class of error
recoverable instead of silently permanent.

---

## G. Risks and Failure Modes

Ordered by expected damage × likelihood:

1. **Mass-produced overfitting (the defining risk).** Automation turns
   multiple-testing from a footnote into the main event: enough candidates
   guarantees lucky gate-passers. *Defenses:* deflated thresholds keyed to the
   recorded N, untouched holdout, parameter-plateau test, complexity penalty,
   promotion rate cap, mandatory incubation. *Residual risk* is nonzero —
   which is what the incubation phase and small initial live sizing exist to
   absorb.
2. **Backtest ≠ live divergence.** The spec compiles to backtest code, but
   live execution runs through System 2. If the two disagree on
   spread/slippage/fill logic, backtest metrics are fiction. This system has
   already seen the config-drift version of this (Layer 2 adapter emitting
   un-runnable T-SQL). *Defense:* the incubation consistency check (live trade
   frequency and win/loss distribution must match backtest confidence bands)
   is explicitly a divergence detector, not just a performance check. Longer
   term: one shared signal-evaluation library for backtest and live.
3. **Silent mistranslation.** Plausible spec, wrong logic (inverted
   comparison, wrong timeframe). It might even pass the gates — as a strategy
   the paper never described. *Defense:* round-trip verification, quarantine
   on disagreement, provenance stored for audit. *Accepted residual:* a
   mistranslated strategy that passes every stage is, functionally, a
   discovered strategy that happens to have wrong provenance — annoying but
   not dangerous, *because the funnel judges behavior, not pedigree.*
4. **Correlation crowding.** Twenty promoted strategies that are secretly one
   trade concentrate risk while appearing to diversify. *Defense:* behavioral
   dedup at stage 3, portfolio-marginal-value scoring in later discovery
   versions, and System 3 aggregate exposure limits as the backstop.
5. **False rejection of good strategies.** Quieter than a bad promotion but
   compounding: systematic gate/cost-model bias starves the pipeline forever.
   *Defense:* shadow-tracking of near-misses (F) gives an empirical
   false-negative rate; family × reason-code aggregates reveal systematic
   bias.
6. **No demotion path.** The prompt asks only for promotion — but an engine
   that only adds strategies degrades the live book monotonically as promoted
   strategies decay. *Design addition:* retirement gates. Every promoted
   strategy is re-vetted at the Sunday boundary on rolling live performance;
   sustained breach → `RETIRED` verdict, same audit trail as rejection. The
   lifecycle must be a loop, not a funnel.
7. **Goodhart's law on the gates.** Any fixed, known target gets gamed by an
   optimizer — the GA will evolve strategies that are shaped like the gates.
   *Defense:* the holdout and incubation judge on data the optimizer never
   touched; complexity penalty limits contortion; periodically re-examine
   what passes the gates but fails incubation — that delta *is* the Goodhart
   gap, measured.
8. **Untrusted-input attacks.** Ingested documents are attacker-controllable
   (prompt injection in a "paper," malicious Pine Script). *Defense:* the
   no-generated-code rule caps the blast radius at one garbage spec; adapters
   never execute source material; translator output is schema-bound.
9. **Operational interference.** A runaway GA eating the database or a
   promotion write racing the Sunday retrain. *Defense:* resource-budgeted
   batch windows, the single Sunday write-window, namespaced artifacts,
   completion-event sequencing (E).
10. **Verdict drift across engine versions.** Metrics bug fixed in March →
    every pre-March verdict is suspect. *Defense:* `code_version` on every
    evaluation makes affected verdicts one query away, and immutable specs
    make re-runs mechanical.

---

## Constraint Compliance

| Constraint | How it's met |
|---|---|
| Python + PostgreSQL + pandas + scikit-learn | Compiler emits `StrategyBase` subclasses (pandas); record is 4 Postgres tables; GA is plain Python; no new infrastructure required. LLM translation is the only external service, and it's optional (Tier 1 + discovery run without it) |
| Testable without live market data | Every stage reads historical store; incubation has a replay mode; CI runs the full pipeline on fixtures with frozen clock |
| Don't break weekly retrain | No mid-week writes; Sunday promotion sequenced *after* retrain completion event; namespaced artifacts |
| Every decision explainable | Specs are human-readable data; every verdict has reason_code + mandatory prose + gate values + N; no generated code anywhere |

## Build Order (dependency-driven)

1. **Spec schema + compiler + golden tests** — re-express 3 of the 18 existing
   strategies as specs and prove the compiled versions reproduce their
   backtests bar-for-bar. This validates the whole foundation before anything
   else exists.
2. **Tracking schema + funnel stages 1–6** wired to the existing backtester
   and gates.
3. **Tier-1 source (parameter sweep)** — first real candidates flow end-to-end.
4. **Anti-overfit battery + Sunday scheduling + incubation.** *Now the engine
   is safe to run unattended.*
5. **GA discovery** (needs 1–4 as its evaluation oracle).
6. **LLM translation + paper/Pine adapters** (highest external dependency,
   least load-bearing — everything above works without it).
7. **Retirement gates + shadow-tracking + gap-driven discovery.**

Note the inversion versus intuition: the "pull ideas from the internet" part —
the headline feature — is built *sixth*, because it is the least trustworthy
input and the most dependent on every safeguard existing first.
