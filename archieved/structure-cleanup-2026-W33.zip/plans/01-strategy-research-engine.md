# Strategy Research Engine — Initial Plan

## What It Does

A pipeline that finds new trading strategies from outside sources, tests them against real market
data, and either promotes them into the system or rejects them with a documented reason.

## Strategy Sources

| Source | Input Format | Example |
|--------|-------------|---------|
| Academic papers | PDF with formulas | "A 20-day Donchian breakout with 2x ATR filter" |
| TradingView scripts | Pine Script code | `ema9 crosses above ema21 and rsi < 30` |
| Blog posts / research | Plain English description | "Buy when price closes above 50-day high with rising volume" |
| LLM-generated ideas | Natural language prompt → rules | "Give me 10 mean-reversion ideas for forex H4" |
| Data mining | Genetic algorithms scanning patterns | Algorithm discovers "close > upper BB and ADX > 25 works on EUR/USD D1" |
| Competition leaderboards | Trading competition top performers | Someone else's winning strategy |

## Pipeline Overview

```
                      ┌──────────────────────┐
     Sources  ───────>│   STRATEGY INGEST    │
   (papers,           │   Parse into rules   │
    scripts,          │   (entry, exit,      │
    plain text,       │    risk filters)     │
    data mining)      └──────────┬───────────┘
                                 │
                       ┌─────────▼───────────┐
                       │   BACKTEST ENGINE    │
                       │   (already exists)   │
                       │   Walk-forward test  │
                       │   on 5 yrs of data   │
                       │   5 assets x 3 TFs   │
                       └──────────┬───────────┘
                                  │
                       ┌──────────▼───────────┐
                       │   VETTING GATES      │
                       │   (already exists)   │
                       │   PF >= 1.5          │
                       │   Sharpe >= 0.8      │
                       │   MaxDD <= 25%       │
                       │   WR >= 40%          │
                       │   Recovery >= 3.0    │
                       │   OOS >= 60 months   │
                       └──────────┬───────────┘
                                  │
                     ┌────────────▼────────────┐
                     │                         │
                PASS ALL                  FAIL ANY
                     │                         │
             ┌───────▼──────┐          ┌───────▼──────┐
             │   PROMOTE    │          │   REJECT     │
             │  -> Layer 2   │          │  -> Archive  │
             │  -> Regime map│          │  with reason │
             └──────────────┘          └──────────────┘
```

## New Components To Build

### 1. Strategy Ingester

Turns external inputs into a `StrategyDefinition` the backtester already understands.

```
class StrategyIngester:
    def from_pine_script(code: str) -> StrategyDefinition
    def from_plain_english(text: str) -> StrategyDefinition
    def from_research_paper(pdf_path: str) -> StrategyDefinition
    def from_genetic_search(data: DataFrame, target_regime: str) -> StrategyDefinition
```

Each source type needs its own parser:
- **Pine Script / plain English** — use an LLM to extract entry/exit/risk rules
- **Data mining** — genetic algorithm that mutates indicator combinations and walks forward
- **Research papers** — LLM reads the paper text and extracts formulas

### 2. Strategy Registry

A database table recording every strategy ever tested:

```
strategy_id | source_type  | source_ref   | date_tested | outcome  | rejection_reason
------------+--------------+--------------+-------------+----------+-------------------
    101     | paper        | arXiv_2301   | 2026-07-10  | REJECTED | Sharpe=0.3 < 0.8
    102     | tradingview  | script_id_5  | 2026-07-10  | PROMOTED | -
    103     | llm_gen      | prompt_42    | 2026-07-11  | REJECTED | OOS=12mo < 60mo
    104     | genetic      | discovery_3  | 2026-07-12  | REJECTED | MaxDD=34% > 25%
```

### 3. Scheduler

- **Weekly** (Sunday with System 1 retrain): scan sources for new ideas
- **Monthly**: evolutionary search on recent data
- **On-demand**: paste a TradingView link or research abstract, get a verdict

## Concrete Example

Input (plain English):
> "Sell EUR/USD on H1 when stochastic %K crosses below 80 from above AND the price is within
> 10% of the upper Bollinger Band AND ADX is above 20"

The ingester extracts:

```python
{
    "name": "Stochastic_BB_Overbought_Reversal",
    "granularity": "H1",
    "entry": [
        "stochastic_K crosses_below 80",
        "price_position_20 > 0.90",
        "adx_14 > 20"
    ],
    "exit": [
        "stochastic_K crosses_above 30",
        "stop_loss": "2 * atr_14"
    ],
    "side": "SELL"
}
```

This feeds into the existing `BacktestEngine`. If it passes all six vetting gates with >= 60
months of OOS data, it promotes itself. If it fails, the report says exactly which gate it
failed and by how much.

## What Already Exists (Reusable)

| Component | Location | Role |
|-----------|----------|------|
| BacktestEngine | `src/layer0/backtest_engine.py` | Walk-forward backtesting |
| StrategyAnalyzer | `src/layer0/strategy_analyzer.py` | Compute metrics (Sharpe, PF, MaxDD, WR) |
| Walk-forward optimization | `src/layer0/qualify_strategies.py` | Parameter grid search |
| Vetting gates | `src/system1/vetting/gates.py` | PF >= 1.5, Sharpe >= 0.8, MaxDD <= 25%, WR >= 40%, Recovery >= 3.0, OOS >= 60mo |
| Attribution engine | `src/system1/attribution/attribute.py` | Per-(strategy x regime x granularity) metrics |
| Regime strategy map | `src/system1/vetting/vet.py` | Rank qualifiers, produce per-regime weights |
| Layer 2 promotion | `src/layer0/layer2_config_adapter.py` | Generate SQL seed scripts for Dim_Strategy |
| Gatekeeper | `src/system1/gatekeeper/train.py` | ML model to gatekeeper | Trades a filter |
| Price data loader | `src/layer0/data_loader.py` | Load from Fact_Market_Prices or CSV |

## Vetting Gates (Thresholds)

| Metric | Threshold | Meaning |
|--------|-----------|---------|
| Profit Factor | >= 1.50 | Gross profit / gross loss |
| Sharpe Ratio | >= 0.80 | Risk-adjusted return |
| Max Drawdown | <= 25% | Worst peak-to-trough loss |
| Win Rate | >= 40% | Percentage of winning trades |
| Recovery Factor | >= 3.00 | Net profit / max drawdown |
| OOS Coverage | >= 60 months | Out-of-sample history required |

## Key Design Rules

1. **Only the ingester is new** — the backtester, gates, attribution, and promotion pipeline
   all already exist and are tested.
2. **Every rejection is documented** — the registry stores exactly which gate failed and the
   actual value vs. the threshold.
3. **No manual promotion** — if a strategy clears all gates, it promotes automatically.
4. **Multi-timeframe, multi-asset** — each strategy is tested on 5 assets x 3 granularities
   (H1, H4, D1) per the existing sandbox model.
5. **Idempotent** — running the same source twice produces the same result and does not
   duplicate entries in the registry.

## File Structure (Proposed)

```
src/
  research/
    __init__.py
    ingester/
      __init__.py
      pine_script_parser.py      # TradingView Pine Script → StrategyDefinition
      plain_english_parser.py    # Natural language → StrategyDefinition (LLM-based)
      paper_parser.py            # PDF/research paper → StrategyDefinition
      genetic_discovery.py       # Evolutionary search for new patterns
      types.py                   # StrategyDefinition, SourceType enum
    registry/
      __init__.py
      db.py                      # Strategy registry table (schema + queries)
    scheduler/
      __init__.py
      weekly_scan.py             # Weekly source scan orchestration
```

## Next Steps

1. Create the `StrategyDefinition` type that bridges from parsed rules → `StrategyBase`
2. Build the Pine Script parser (highest-value first — TradingView is the largest source of
   strategy ideas)
3. Build the plain-English parser (LLM-based, for blog posts and natural language prompts)
4. Create the registry table in PostgreSQL
5. Wire the scheduler into the existing Sunday cron
6. Build the genetic discovery module (lower priority — compute-intensive)
